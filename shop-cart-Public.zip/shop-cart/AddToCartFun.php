<?php
#hostname,username,password,dbname
session_start();
$user = "1";
// $shippingmethod;
global $total;
global $order;

$con = mysqli_connect("localhost","root","","BoardGames");


if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


function AddCart(){
  //check if product is already in the cart
	if(!in_array($_GET['ID'], $_SESSION['cart'])){
		array_push($_SESSION['cart'], $_GET['ID']);

		$_SESSION['message'] = 'Product added to cart';
	}
	else{
		$_SESSION['message'] = 'Product already in cart';
	}
  print '<script>alert("Item Added")</script>';
	//unset($_SESSION["cart"]);
}
function deleteFromCart(){

	$key = array_search($_GET['id'], $_SESSION['cart']);
	unset($_SESSION['cart'][$key]);

	unset($_SESSION['qty_array'][$_GET['index']]);
	//rearrange array after unset
	$_SESSION['qty_array'] = array_values($_SESSION['qty_array']);

	$_SESSION['message'] = "Product deleted from cart";

   print '<script>alert("Item Removed")</script>';
}


  function viewCart(){

						//initialize total
						global $total;
						$total = 0;
            $subtotal = 0;
						if(!empty($_SESSION['cart'])){
						//connection
						$conn = new mysqli('localhost', 'root', '', 'BoardGames');
						//create array of initail qty which is 1
						 $index = 0;

 						if(!isset($_SESSION['qty_array'])){
 							$_SESSION['qty_array'] = array_fill(0, count($_SESSION['cart']), 1);
 						}
						$sql = "SELECT * FROM Product WHERE ProductID IN (".implode(',',$_SESSION['cart']).")";
						$query = $conn->query($sql);
							while($row = $query->fetch_assoc()){
                ?>

								<tr>
                <td>
                    <form action="" method="GET">
                    <a href="cart.php?id=<?php echo $row['ProductID']; ?>&index=<?php echo $index; ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span>Remove</a>
                    </form>
									</td>

                <?php
                      echo'
                      <td><img width="100" src="data:image/jpeg;base64,'.base64_encode( $row['Image'] ).'"/></td>'
                     ?>


									<td><?php echo $row['Name']; ?></td>

									<td><?php echo number_format($row['Price'],2); ?></td>
<form method="POST" action="cart.php">
									<input type="hidden" name="indexes[]" value="<?php echo $index; ?>"/>

									<td><input type="text" class="form-control"  value="<?php echo $_SESSION['qty_array'][$index]; ?>" name="qty_<?php echo $index; ?>"></td>

									<td><?php echo number_format($_SESSION['qty_array'][$index]*$row['Price'],2); ?></td>

									<?php $total += $_SESSION['qty_array'][$index]*$row['Price']; ?>
								</tr>
								<?php
								$index ++;
							}
						}
						else{
							?>
							<tr>
								<td colspan="4" class="text-center">No Item in Cart</td>
							</tr>
							<?php
            }
           ?> <tr>
             <th></th>
						<td colspan="4" align="right"><b>Total</b></td>
						<td><b><?php echo number_format($total, 2); ?></b></td>
          </tr>

            <button type="submit" name="save" >Save</button>
</form>

          <?php


            //unset($_SESSION["cart"]);

  }

  function UpdateQuantity(){


		foreach($_POST['indexes'] as $key){
			$_SESSION['qty_array'][$key] = $_POST['qty_'.$key];

		}

		$_SESSION['message'] = 'Cart updated successfully';
		header('location: cart.php');

  }

  function Checkout(){
		global $total;
		global $user;
		global $order;
if(isset($_SESSION['user'])){


		$random = md5(microtime(true).mt_Rand());
		$tax = 0.12;
		$totalcost = ($total * $tax) + $total;

    $con = mysqli_connect("localhost","root","","BoardGames");
		// $_SESSION['user'] = $user;

		$account = $_SESSION['user'];
		$_SESSION['ShippingMethod'] = $_GET['ShippingMethod'];
		$ship = $_SESSION['ShippingMethod'];

		print $random;

		$sql = "Insert INTO Orders(AccountID,Date,ShippingMethod,Status,Tracking,TotalPrice,Tax)
		Values(".$account.", CURDATE(), '$ship', 'Sended','$random', ".$totalcost.",".$tax * $total.")";

		$insertPro = mysqli_query($con, $sql) or die(mysqli_error());

		foreach($_SESSION['cart'] as $key => $index){
			//$sq = "Insert INTO Contain(OrderID,ProductID, Quantity, price) Values(LAST_INSERT_ID(),".$_SESSION['cart'][$key].", ".$_SESSION['qty_array'][$key].", 'Select price From Product where ProductID In(".implode(',',$_SESSION['cart']).")')";
			$sq = "INSERT INTO Contain(OrderID,ProductID,Quantity,price)

				SELECT LAST_INSERT_ID(), ProductID, ".$_SESSION['qty_array'][$key].", price From Product

				Where ProductID IN (".implode(',',$_SESSION['cart']).")";
				$_SESSION['orderPlace'] = mysqli_insert_id($con) ;

		}
		$insertPro = mysqli_query($con, $sq) or die(mysql_error());



   if(! $insertPro ) {
    die('Could not update data: ');
    }
    else{

			//$order = $orderId;
			echo "Updated data successfully\n";
			// unset($_SESSION["cart"]);
			 //header('location: cartConfirm.php');
			 header( "refresh:1;url=cartConfirm.php?id" );
    }

}

else{
  header( "refresh:0; url=login.php" );
}

	}


	function invoice($order){
		global $con;



		///////////Table Order with Shipping Address and Payment Method///////////
		//$tablaOrder = "SELECT * FROM ShippingAddress NATURAL JOIN Orders  NATURAL JOIN PaymentMethod WHERE OrderID = $order ";
    $tablaOrder = "SELECT * FROM Client NATURAL JOIN Orders  NATURAL JOIN PaymentMethod WHERE OrderID = $order ";

		$result = mysqli_query($con,$tablaOrder);
		$row =  mysqli_fetch_assoc($result);


		//////////////////////Tabla Account///////////////////////////////////////

		$tablaAccount = "SELECT * FROM Client NATURAL JOIN Orders WHERE OrderID = $order ";
		$result2 = mysqli_query($con,$tablaAccount);
		$row2 =  mysqli_fetch_assoc($result2);


		////////////////////////Table Contain ////////////////////////////////////
		// $tablaContain = "SELECT * FROM Orders NATURAL JOIN Contain WHERE  OrderID = $orderId ";
		$tablaContain ="SELECT * FROM Contain NATURAL JOIN Product WHERE OrderID = $order";
		$result3 = mysqli_query($con,$tablaContain);


		//////////////////////////////////////////////////////////////////////////


		$date = $row['Date'];
		$street1 = $row['Street1'];
		$street2 = $row['Street2'];
		$city = $row['City'];
		$country = $row['Country'];
		$postalCode = $row['PostalCode'];
		$state = $row['State'];
		$cardNumber = $row['CardNumber'];
		$cardType = $row['CardType'];
		$total = $row['TotalPrice'];
		$tax = $row['Tax'];
		$tracking = $row['Tracking'];
		$shippingMethod = $row['ShippingMethod'];
		$phone = $row2['PhoneNumber'];
		$masked =  str_pad(substr($cardNumber, -4), strlen($cardNumber), '*', STR_PAD_LEFT);



			echo'
				<div name = "recibo" ;class="row">
						<div class="col-lg-12">
								<div class="card px-2">
										<div class="card-body">
												<div class="container-fluid">
													<h3 class="text-right my-5">Order #&nbsp;&nbsp;'.$order.'</h3>
													<hr>
												</div>
												<div class="container-fluid d-flex justify-content-between">
													<div class="col-lg-3 pl-0">
														<p class="mt-5 mb-2"><b>Shipping Address</b></p>
														<p>'.$street1.'<br>'.$street2.'<br>'.$postalCode.','.$city.','.$state.'<br>'.$country.' </p><br>
														<p>Phone Number : '.$phone.'</p>
													</div>
													<div class="col-lg-3 pr-0">
														<p class="mt-5 mb-2 text-right"><b>Payment Method</b></p>
														<p class="text-right">'.$cardType.' '.$masked.'</p>
														<p class="mt-5 mb-2 text-right"><b>Tracking Number</b></p>
														<p class="text-right">'.$tracking.'</p>
														<p class="text-right">Shipping Method : '.$shippingMethod.'</p>
													</div>
												</div>
												<div class="container-fluid d-flex justify-content-between">
													<div class="col-lg-3 pl-0">
														<p>Ordered on: '.$date.'</p>
													</div>
												</div>
												<div class="container-fluid mt-5 d-flex justify-content-center w-100">
													<div class="table-responsive w-100">
															<table class="table">
																<thead>
																	<tr class="bg-dark text-white">
																			<th>#</th>
																			<th>Product Name</th>
																			<th class="text-right">Quantity</th>
																			<th class="text-right">Unit cost</th>
																			<th class="text-right">Total</th>
																		</tr>
																</thead>';
																$count = 1;
																$subTotal = 0;
																while ($row3 =  mysqli_fetch_assoc($result3)){
																		$name = $row3['Name'];
																		$quantity = $row3['Quantity'];
																		$price = $row3['price'];
																		$totalPerProduct = $price * $quantity;
																		$subTotal = $subTotal + $totalPerProduct;

																		echo '
																			<tbody>
																				<tr class="text-right">
																					<td class="text-left">'.$count.'</td>
																					<td class="text-left">'.$name.'</td>
																					<td>'.$quantity.'</td>
																					<td>'.$price.'</td>
																					<td>'.$totalPerProduct.'</td>
																				</tr>
																				</tbody>';
																				$count++;
																			}


																echo '
															</table>
														</div>
												</div>
												<div class="container-fluid mt-5 w-100">
													<p class="text-right mb-2">SubTotal : $'.$subTotal.'</p>
													<p class="text-right">Tax (12%) : $'.Round(0.12 * $subTotal,2).'</p>
													<h4 class="text-right mb-5">Total : $'.  Round(0.12 * $subTotal + $subTotal,2 )  .'</h4>
													<hr>
												</div>
												<div class="container-fluid w-100">
													<button onclick="myFunction()" class="btn btn-primary float-right mt-4 ml-2">Print</button>

												</div>
										</div>
								</div>
						</div>
				</div>
				<script>
							function myFunction() {
										window.print();
																		}
				</script>';


unset($_SESSION['cart']);

				}
?>
