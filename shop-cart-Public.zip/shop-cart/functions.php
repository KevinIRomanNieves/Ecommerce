<?php


  $db_host = "localhost";
  $db_name = "BoardGames";
  $db_usuario = "root";
  $db_pass = "";

  $conexion = mysqli_connect($db_host,$db_usuario,$db_pass,$db_name);




function tablaProductos(){
  global $conexion;
  $tablaProducts = "SELECT * FROM Product";
  $result = mysqli_query($conexion,$tablaProducts);


    echo '
    <form action="modify_product.php"  >
      <div class="table-responsive">

    <table id="order-listing" class="table">

      <thead>
        <tr class="bg-primary text-white">
            <th>Product ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
      </thead>
  ';

      while ($row =  mysqli_fetch_assoc($result)){
        echo'
          <tbody>
            <tr>
              <td>'.$row['ProductID'].'</td>
              <td>'.$row['Name'].'</td>
              <td>'.$row['brand'].'</td>
              <td>'.$row['price'].'</td>
              <td>'.$row['QuantityRemaning'].'</td>
              <td>'.$row['Status'].'</td>

                <td class="text-right">
                ';
              //echo ' <a href="modify_product.php id="'.$fila['pID'].'" ">Edit</a>';
              echo '<a class="btn btn-info mr-2" href=modify_product.php?id='.$row['ProductID'].'>Edit</a>';
              //echo '<input  name= "Edit" type="submit" id = "'.$fila[0].'" value="Edit" class="btn btn-light">
              echo'
                </td>
            </tr>
            </tbody>';
          }
          //Falta el pagination
          echo'</table>';



}


function modifyProducts($idProduct){
  global $conexion;
  $ProductdDetails = "SELECT * FROM Product WHERE ProductID = $idProduct" ;
  $resultado = mysqli_query($conexion,$ProductdDetails);
  $row =  mysqli_fetch_assoc($resultado);
  $QuantityRemaning = $row['QuantityRemaning'];
  $productName = $row['Name'];
  $price = $row['price'];
  $dprice = $row['DealerPrice'];
  $brand = $row['brand'];
  $provider = $row['Provider'];
  $age = $row['Age'];
  $size = $row['Size'];
  $weight = $row['Weight'];
  $players = $row['Players'];
  $Description = $row['Description'];
  echo '
  <form action="modify_product.php?id='.$idProduct.'" method= "post" enctype="multipart/form-data">
  <div>
    <p name="id" value="'.$idProduct.'">Product ID : '.$idProduct.'</p>
    <p>Status :</p>

    <div class="form-group">
          <select class="form-control" name="status">
              <option  value = "Enable">Enable</option>
              <option  value = "Disable">Disable</option>
          </select>

    </div>

    <p>Name</p>
    <div class="form-group">
      <input required="required" type="text" class="form-control" name="name" placeholder="'.$productName.'" >
    </div>

    <p>Category</p>
    <div class="form-group">
      <select class="form-control">
          <option value="3">Card Game</option>
          <option value="1">Trivia</option>
          <option value="2">Strategy</option>
          <option value="5">Educational</option>
          <option value="6">Puzzle</option>
          <option value="7">Fantasy</option>
          <option value="8">Adventure</option>
          <option value="9">Memory</option>
        </select>
    </div>

    <p>Sub Category</p>
    <div class="form-group" name="SubCategory">
        <select class="form-control">
          <option value="4">Matching</option>
          <option value="2">Fictional</option>
          <option value="5">Gambling</option>
          <option value="6">Historical</option>
          <option value="8">War Games</option>
          <option value="9">Abstract</option>
          <option value="10">Math</option>
          <option value="11">Logic</option>
          <option value="12">Middle Earth</option>
        </select>
    </div>

    <p>Quantity</p>
    <div class="form-group">

      <select class="form-control" name="QuantityRemaning">';
          for ($num = 0;$num < 100;$num++){
            echo '<option value="'.$num.'">'.$num.'</option>';
          }

          echo '
          </select>
    </div>

    <p>Price :</p>
    <div class="form-group">
      <input type="text" class="form-control" name="price" placeholder="'.$price.'">
    </div>

    <p>Dealer Price :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "dprice" placeholder="'.$dprice.'" >
    </div>

    <p>Brand :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Brand" placeholder="'.$brand.'" >
    </div>

    <p>Provider :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Provider" placeholder="'.$provider.'" >
    </div>

    <p>Age :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Age" placeholder="'.$age.'" >
    </div>

    <p>Size :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Size" placeholder="'.$size.'" >
    </div>

    <p>Weight :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Weight" placeholder="'.$weight.'" >
    </div>

    <p>Players :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Players" placeholder="'.$players.'" >
    </div>

    <div class="form-group">
      <textarea  name="Description" rows="6" class="form-control" placeholder="'.$Description.'"></textarea>
    </div>

      <div class="wrapper mb-5 mt-4">
        <span class="badge badge-warning text-white">Note : </span>
        <p class="d-inline ml-3 text-muted">Image size is limited to not greater than 1MB .</p>
      </div>
      <div class="wrapper mb-5 mt-4">
        
        <input type="file" class="dropify" name="image">
        
      </div>
    <div class="form-group mt-5">
      <input type="submit"   name="update" value = "Update" class="btn btn-success mr-2" >
      <a class="btn btn-outline-danger" href=/shopMesa/ShopAdmin/Products.php>Cancel</a>
    </div>
</div>
  </form>
  ';

    if(isset($_POST['update']))
    {
      $statusUpdate = $_POST['status'];
      $nameUpdate = $_POST['name'];
      $priceUpdate = $_POST['price'];
      $descUpdate = $_POST['Description'];
      $dPriceUpdate = $_POST['dprice'];
      $brandUpdate = $_POST['Brand'];
      $provUpdate = $_POST['Provider'];
      $playersUpdate = $_POST['Players'];
      $ageUpdate = $_POST['Age'];
      $sizeUpdate = $_POST['Size'];
      $weightUpdate = $_POST['Weight'];
      $quantityUpdate = $_POST['QuantityRemaning'];
      $image = $_FILES['image']['tmp_name'];
      $image = addslashes(file_get_contents($image));
      echo $nameUpdate;

      $updateProduct = "UPDATE Product
      SET Name = '$nameUpdate',Status = '$statusUpdate', Price='$priceUpdate', Description = '$descUpdate'
      , DealerPrice = '$dPriceUpdate', brand = '$brandUpdate', Provider = '$provUpdate', Players = '$playersUpdate',
      Age = '$ageUpdate', Size = '$sizeUpdate', Weight = '$weightUpdate', Image = '$image', QuantityRemaning = '$quantityUpdate'
       WHERE ProductID = $idProduct ";
      $retval = mysqli_query($conexion,$updateProduct);
      if(! $retval ) {
               die('Could not update data: ' . mysqli_error());
            }else{

            echo "Updated data successfully\n";



          }

    }

}




function addProduct(){
  global $conexion;


  echo '
  <form action="Create_product.php" method= "post" enctype="multipart/form-data">
  <div>
    <p>Status :</p>

    <div class="form-group">
          <select class="form-control" name="Status">
              <option  value = "Enable">Enable</option>
              <option  value = "Disable">Disable</option>
          </select>

    </div>

    <p>Name</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "name" placeholder="Product name" >
    </div>

    <p>Category</p>
    <div class="form-group">
      <select class="form-control">
        <option value="3">Card Game</option>
        <option value="1">Trivia</option>
        <option value="2">Strategy</option>
        <option value="5">Educational</option>
        <option value="6">Puzzle</option>
        <option value="7">Fantasy</option>
        <option value="8">Adventure</option>
        <option value="9">Memory</option>
        </select>
    </div>
    <p>Sub Category</p>
    <div class="form-group">
      <select class="form-control" name="SubCategory">
          <option value="1">Historical</option>
          <option value="4">Matching</option>
          <option value="2">Fictional</option>
          <option value="5">Gambling</option>
          <option value="6">Historical</option>
          <option value="8">War Games</option>
          <option value="9">Abstract</option>
          <option value="10">Math</option>
          <option value="11">Logic</option>
          <option value="12">Middle Earth</option>
          
        </select>
    </div>

    <p>Quantity</p>
    <div class="form-group">

      <select class="form-control" name="QuantityRemaning" >';
          for ($num = 0;$num < 100;$num++){
            echo '<option value=".$num">'.$num.'</option>';
          }

          echo '
          </select>
    </div>
    <p>Price :</p>
    <div class="form-group">
      <input type="text" class="form-control" name ="Price" placeholder="Price">
    </div>

    <p>Dealer Price :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "DealerPrice" placeholder="Dealer Price" >
    </div>

    <p>Brand :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Brand" placeholder="Brand" >
    </div>

    <p>Provider :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Provider" placeholder="Provider" >
    </div>

    <p>Age :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Age" placeholder="Age" >
    </div>

    <p>Size :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Size" placeholder="Size" >
    </div>

    <p>Weight :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Weight" placeholder="Weight" >
    </div>

    <p>Prayers :</p>
    <div class="form-group">
      <input type="text" class="form-control" name = "Players" placeholder="Players" >
    </div>


    <div class="form-group">
      <textarea name="Description" id="address" rows="6" class="form-control" placeholder="Description"></textarea>
    </div>

      <div class="wrapper mb-5 mt-4">
        <span class="badge badge-warning text-white">Note : </span>
        <p class="d-inline ml-3 text-muted">Image size is limited to not greater than 1MB .</p>
      </div>
      <div class="wrapper mb-5 mt-4">
        
          <input type="file" class="dropify" name="image">
        
      </div>
    <div class="form-group mt-5">
      <input type="submit"   name="createProduct" value = "Add" class="btn btn-success mr-2" >
      <a class="btn btn-outline-danger" href=/shopMesa/ShopAdmin/Products.php>Cancel</a>
    </div>
</div>
  </form>
  ';

    if(isset($_POST['createProduct']))
    {
      $image = $_FILES['image']['tmp_name'];
      $image = addslashes(file_get_contents($image));

      $createStatus = $_POST['Status'];
      $createName = $_POST['name'];
      $subCat = $_POST['SubCategory'];
      $createPrice = $_POST['Price'];
      $createRemaning = $_POST['QuantityRemaning'];
      $createDealerPrice = $_POST['DealerPrice'];
      $createBrand = $_POST['Brand'];
      $createProvider = $_POST['Provider'];
      $createPlayers = $_POST['Players'];
      $createAge = $_POST['Age'];
      $createSize = $_POST['Size'];
      $createWeight = $_POST['Weight'];
      $createStatus = $_POST['Status'];
      $Description = $_POST['Description'];

      $createProduct = "INSERT INTO Product (name,SubCategoryID,status,Image,Price,QuantityRemaning,DealerPrice,brand,Provider,Description,Players, Age, Size, Weight)
      VALUES ('$createName','$subCat','$createStatus','$image','$createPrice','$createRemaning', '$createDealerPrice', '$createBrand', '$createProvider' ,'$Description', '$createPlayers' ,'$createAge', '$createSize' , '$createWeight' )";

      $retval = mysqli_query($conexion,$createProduct);
      if(! $retval ) {
               die('Could not update data: ');
            }else{

            echo "Updated data successfully\n";



          }

    }

}



function login(){
  global $conexion;
  		//php // login.php
  		/* This page lets people log into the site. */


  		// Check if the form has been submitted:
  		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  		// CRUD
  		// Connect and select:
  		IF (!$dbc = $conexion) {
  			print '<p style="color: red;">'.$MYSQL_ERRNO.':'.$MYSQL_ERROR.'</p>';
  			exit();
  		}
  		//
  		// Handle the form:
  		if ( (!empty($_POST['user'])) && (!empty($_POST['password'])) ) {
  			$email =  mysqli_real_escape_string($conexion,trim(strip_tags($_POST['email'])));
  			$password =  mysqli_real_escape_string($conexion,trim(strip_tags($_POST['password'])));

  			// Define the query.
  			$query = "SELECT email, password, role FROM client WHERE email='{$_POST['user']}' AND password='{$_POST['password']}'";
  			if ($r = @mysqli_query($conexion,$query)) { // Run the query.
  				if (mysqli_num_rows($r) == 1) { //  Confirm that the SELECT query returned a row prior to fetching it
  					$row = mysqli_fetch_array($r); // Retrieve the information.
  					session_start();
  					$_SESSION['email'] = $row['email'];
  					$_SESSION['role'] = $row['role'];
  					mysqli_close($dbc);
  					if (!is_administrator()) {
  						header ('Location: menu_estudiante.php');
  						exit();
  					} else {
  						header ('Location: menu_administrador.php');
  						exit();
  					}
  				} else { // Incorrect!

  					print '<p>La dirección de email y/o contraseña incorrectos!<br /><a href="javascript:history.back()">Intentar</a> nuevamente!</p>';
  				}
  			} else { // Couldn't get the information.
  				print '<p>No se pudo obtener la información del usuario porque:<br />' . mysqli_error($dbc) . '.</p><p>The query being run was: ' . $query . '</p>';
  			}
  		} else { // Forgot a field.

  			print '<p>Favor de entrar dirección de email y contraseña!<br /><a href="javascript:history.back()">Intentar</a> nuevamente!</p>';
  		}
  		//
  	} else { // Display the form.

  		print '<form action="" method="post">
          <p>Dirección Email: <input type="text" name="email" size="20" /></p>
          <p>Contraseña: <input type="password" name="password" size="20" /></p>
          <p><input type="submit" name="submit" value="Log In!" /></p>
  		  </form>';

  	}


}



 ?>
<script>
function previewFile() {
  var preview = document.querySelector('img');
  var file    = document.querySelector('input[type=file]').files[0];
  var reader  = new FileReader();

  reader.onloadend = function () {
    preview.src = reader.result;
  }

  if (file) {
    reader.readAsDataURL(file);
  } else {
    preview.src = "";
  }
}
</script>
