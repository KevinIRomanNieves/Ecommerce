<?php 
#hostname,username,password,dbname
$con = mysqli_connect("localhost","root","","BoardGames");
$pressedBtn;
$Cat;
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//group by name A to Z ------------------------------------------

function fromToAZ($getCat)
{
    global $con;
    $cat = $getCat;
        // $getCat = "CardGame";
    $get_items = "select pID,img,name,info,price from Product where Categorie='$cat' order by name  ";

   
    #database connection, query
    $run_items = mysqli_query($con, $get_items);
    while($row_items=mysqli_fetch_array($run_items)){
        $item_img = $row_items['img'];
        $item_name = $row_items['name'];
        $item_info = $row_items['info'];
        $item_price = $row_items['price'];
        $item_id = $row_items['pID'];
        
        echo '<img class="span3"  src="data:image/jpeg;base64,' . base64_encode( $item_img ) . '" />';
        echo"<div class='well well-small'>
                <div class='row-fluid'>
                <div class='span2'>
                
                </div>

                    <div class='span6'>
                        <h4 style='margin-left:10px;'>$item_name</h4>
                        
                            <p style='margin-left:20px;'>$item_info</p>
                    
                        </div> 
                </div>
                <div class='span4 alignR'>
                    
                    <h3>$ $item_price</h3>
                </div>    
                    <div style='margin-left:200px;'>
                        <a href='product_details.html' class='defaultBtn'><span class=' icon-shopping-cart'></span> Add to cart</a>
                        <a href='product_details.php? pressedBtn=$item_id' class='shopBtn'>VIEW</a>
                    </div>
            </div>";
    }
    
}

// Price high to low----------------------------------------------------------------------------
function PriceHighToLow()
{
    global $con;
    $get_items = "select pID,img,name,info,price from Product order by price Desc ";
    #database connection, query
    $run_items = mysqli_query($con, $get_items);
    while($row_items=mysqli_fetch_array($run_items)){
        $item_img = $row_items['img'];
        $item_name = $row_items['name'];
        $item_info = $row_items['info'];
        $item_price = $row_items['price'];
        $item_id = $row_items['pID'];
        
        echo '<img class="span3"  src="data:image/jpeg;base64,' . base64_encode( $item_img ) . '" />';
        echo"<div class='well well-small'>
                <div class='row-fluid'>
                <div class='span2'>
                
                </div>

                    <div class='span6'>
                        <h4 style='margin-left:10px;'>$item_name</h4>
                        
                            <p style='margin-left:20px;'>$item_info</p>
                    
                        </div> 
                </div>
                <div class='span4 alignR'>
                    
                    <h3>$ $item_price</h3>
                </div>    
                    <div style='margin-left:200px;'>
                        <a href='product_details.html' class='defaultBtn'><span class=' icon-shopping-cart'></span> Add to cart</a>
                        <a href='product_details.php? pressedBtn=$item_id' class='shopBtn'>VIEW</a>
                    </div>
            </div>";
    }
    
}


// Price low to high----------------------------------------------------------------------------
function PriceLowToHigh()
{
    global $con;
    $get_items = "select pID,img,name,info,price from Product order by price Asc ";
    #database connection, query
    $run_items = mysqli_query($con, $get_items);
    while($row_items=mysqli_fetch_array($run_items)){
        $item_img = $row_items['img'];
        $item_name = $row_items['name'];
        $item_info = $row_items['info'];
        $item_price = $row_items['price'];
        $item_id = $row_items['pID'];
        
        echo '<img class="span3"  src="data:image/jpeg;base64,' . base64_encode( $item_img ) . '" />';
        echo"<div class='well well-small'>
                <div class='row-fluid'>
                <div class='span2'>
                
                </div>

                    <div class='span6'>
                        <h4 style='margin-left:10px;'>$item_name</h4>
                        
                            <p style='margin-left:20px;'>$item_info</p>
                    
                        </div> 
                </div>
                <div class='span4 alignR'>
                    
                    <h3>$ $item_price</h3>
                </div>    
                    <div style='margin-left:200px;'>
                        <a href='product_details.html' class='defaultBtn'><span class=' icon-shopping-cart'></span> Add to cart</a>
                        <a href='product_details.php? pressedBtn=$item_id' class='shopBtn'>VIEW</a>
                    </div>
            </div>";
            
    }
    
}


?>