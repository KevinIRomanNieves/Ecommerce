<?php 
#hostname,username,password,dbname
$con = mysqli_connect("localhost","root","","BoardGames");


if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

function productsOnIndexPage(){
    global $con;
    
    $get_items = "select * from Product where Status='Enable' order by Rand()  ";
    #database connection, query
    $run_items = mysqli_query($con, $get_items);
    while($row_items=mysqli_fetch_array($run_items)){
        $item_img = $row_items['Image'];
        $item_name = $row_items['Name'];
        
        $item_price = $row_items['Price'];
        $item_id = $row_items['ProductID'];

    
    echo"
    <div id='newProductCar' class='carousel slide'>
    <div class='carousel-inner'>

    <ul class='thumbnails'>
    <li class='span8'>
      <div class='thumbnail'>

        <a class='zoomTool' href='product_details.php? ID=$item_id' title='add to cart'><span class='icon-search'></span> QUICK VIEW</a>";
        echo'<img src="data:image/jpeg;base64,' . base64_encode( $item_img ) . '" />';
        echo"
        
        <div class='caption cntr'>
            <p>$item_name</p>
            <p><strong> $ $item_price</strong></p>
            
            
            <br class='clr'>
        </div>
      </div>
      </li>
      </ul>";

    }
}

function getProducts($query)
{
    global $con;
    // $pressedBtn;
    $get_items = $query;
    
    
    #database connection, query
    $run_items = mysqli_query($con, $get_items);
    while($row_items=mysqli_fetch_array($run_items)){
        $item_img = $row_items['Image'];
        $item_name = $row_items['Name'];
        $item_info = $row_items['Description'];
        $item_price = $row_items['Price'];
        $item_id = $row_items['ProductID'];
        
        echo"<div class='well well-small'>
                <div class='row-fluid'>
                <div class='span3'>";
                echo '<img  src="data:image/jpeg;base64,' . base64_encode( $item_img ) . '" />';


             echo" </div>

                    <div class='span6'>
                        <h4 style='margin-left:10px;'>$item_name</h4>
                        
                            <p style='margin-left:20px;'>$item_info</p>
                    
                        </div> 
                </div>
                <div class='span1 '>
                    <h3>$$item_price</h3>
                    
                </div>  
                
                    <div style='margin-left:100px;'>
                    
                    <from action='' method='POST'>
                        <a href='product_details.php? ID=$item_id' class='shopBtn' > View </a>
                    </form>
                    </div>
            </div>";
    }
}

function ShowProductDetails(){
    global $con;
    $id = $_GET['ID'];
    
    $get_items = "SELECT ProductID,Image,Name,Description,QuantityRemaning,Price,Age,Players FROM Product WHERE ProductID='$id' ";

    #database connection, query
    $run_items = mysqli_query($con, $get_items);
    while($row_items=mysqli_fetch_array($run_items)){
        $item_id = $row_items['ProductID'];
        $item_img = $row_items['Image'];
        $item_name = $row_items['Name'];
        $item_info = $row_items['Description'];
        $item_price = $row_items['Price'];
        $item_quantity = $row_items['QuantityRemaning'];
        $item_age = $row_items['Age'];
        $item_players = $row_items['Players'];
        
        echo '<img class="span3" src="data:image/jpeg;base64,' . base64_encode( $item_img ) . '" />';
        echo"<div class='well well-small'>
            <div class='row-fluid'>
                <div class='span5'>
                    <div>
                        <div class='carousel-inner'>
                            <div class='item active'>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class='span7'>
                
                    
                    <h3> $item_name </h3>
                    <hr class='soft'/>
                    <form class='form-horizontal qtyFrm'>
                    <div class='control-group'>
					<label class='control-label'><span>Price: $ $item_price</span></label>
					<div class='controls'>
					
					</div>
				  </div>
				  <h4>$item_quantity items in stock</h4>
                  <p>$item_info</p>
                  <p>Age: $item_age</p>
                  <p>Players: $item_players</p>
                  <form action='' method='GET'>
                    <a href='cart.php?ID=$item_id' name='add' class='shopBtn' > Add to Cart </a>
                  </form>
				</form>
                </div>
            </div>

        </div>";
        
    }
}

function Categories(){
    global $con;
    $getCat = "SELECT DISTINCT * FROM Category";
    $runcat = mysqli_query($con, $getCat);

    while($row = mysqli_fetch_array($runcat)){
        $cat = $row['CategoryName'];
        $id = $row['CategoryID'];
        echo"
        
        <li><a href='list-view.php?cat=$id'> $cat </a> </li>
        
        ";
        SubCategories($id);
        
    }
}
function SubCategories($parent){
    global $con;
    $getCat = "SELECT  * FROM SubCategory  Where CategoryID =$parent  OR SubCategoryID=$parent";
    $runcat = mysqli_query($con, $getCat);

    while($row = mysqli_fetch_array($runcat)){
        $cat = $row['SubCategoryName'];
        $id = $row['SubCategoryID'];
        echo"
        
        <li>&emsp;&emsp;<a href='list-view.php?sub=$id'> $cat </a> </li>
        
        ";
    }
}
?>