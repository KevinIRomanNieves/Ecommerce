<?php
$db_host = "localhost";
$db_name = "BoardGames";
$db_usuario = "root";
$db_pass = "";

$conexion = mysqli_connect($db_host,$db_usuario,$db_pass,$db_name);

function addUser(){

    global $conexion;


        echo '
        <form action="register.php" method= "post" enctype="multipart/form-data">
        <div>

          <div class="form-group">
            <input type="text" class="form-control" name = "firstName" placeholder="First Name" >
          </div>


          <div class="form-group">
            <input type="text" pattern="[A-Z]{1}" class="form-control" name ="initMiddleName" placeholder="Initial Middle Name">
          </div>


          <div class="form-group">
            <input type="text" class="form-control" name = "lastName" placeholder="Last Name" >
          </div>


          <p>Billing Address :</p>
          <div class="form-group">
            <input type="text" class="form-control" name = "street1" placeholder="Address Line 1" >
          </div>


          <div class="form-group">
            <input type="text" class="form-control" name = "street2" placeholder="Address Line 2" >
          </div>


          <div class="form-group">
            <input type="text" class="form-control" name = "city" placeholder="City" >
          </div>


          <div class="form-group">
            <input type="text" class="form-control" name = "state" placeholder="State" >
          </div>



          <div class="form-group">
            <input type="text" class="form-control" name = "country" placeholder="Country" >
          </div>


          <div class="form-group">
            <input type="text" class="form-control" name = "phone" placeholder="Phone Number" >
          </div>



          <div class="form-group">
            <input type="email" class="form-control" name = "email" placeholder="Email" >
          </div>

          <div class="form-group">
            <input type="password" class="form-control" name = "password" placeholder="Password" >
          </div>




          <div class="form-group mt-5">
            <input type="submit"   name="createUser" value = "Add" class="btn btn-success mr-2" >
            <a class="btn btn-outline-danger" >Cancel</a>
          </div>


      </div>
        </form>
        ';

          if(isset($_POST['createUser']))
          {

            // $createRole = $_POST['role'];
            $createFname = $_POST['firstName'];
            $createLname = $_POST['lastName'];
            $createPassword = $_POST['password'];
            $createMiddleName = $_POST['initMiddleName'];
            $createStreet1 = $_POST['street1'];
            $createStreet2 = $_POST['street2'];
            $createCity = $_POST['city'];
            $createState = $_POST['state'];
            $createCountry = $_POST['country'];
            $createPhone = $_POST['phone'];
            $createEmail = $_POST['email'];


            $passHash = password_hash($createPassword, PASSWORD_DEFAULT);

            $createUser = "INSERT INTO Client (Fname,Lname,Minit,Password,Street1,Street2,City,
              State,Country,PhoneNumber,Email)
            VALUES ('$createFname','$createLname','$createMiddleName','$passHash','$createStreet1','$createStreet2','$createCity',
                    '$createState', '$createCountry', '$createPhone' ,'$createEmail')";

            $retval = mysqli_query($conexion,$createUser);



            if(! $retval ) {
                     die('Could not update data: ');
                  }else{

                  echo "Updated data successfully\n";



                }

          }

}
?>
